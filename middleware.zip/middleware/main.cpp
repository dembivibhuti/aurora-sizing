#include <iostream>
#include <vector>
#include <future>
#include <boost/asio.hpp>
#include "server/secserv.h"


int main(int argc, char *argv[]) {
    int numOfIOContexts = 16, threadsPerContext = 1, threadsForRepository = 16;
    unsigned short port = 4008;
    if (argc == 4) {
        port = atoi(argv[1]);
        numOfIOContexts = atoi(argv[2]);
        threadsPerContext = atoi(argv[3]);
        threadsForRepository = atoi(argv[4]);
    }

    std::cout << "I/O contexts          : " << numOfIOContexts << std::endl;
    std::cout << "Threads per context   : " << threadsPerContext << std::endl;

    std::shared_ptr<boost::asio::io_context> repo_context(new boost::asio::io_context());
    boost::asio::executor_work_guard<decltype(repo_context->get_executor())> workGuard{repo_context->get_executor()};
    std::shared_ptr<boost::asio::io_context> context(new boost::asio::io_context());

    Server server(numOfIOContexts, threadsPerContext, *context, *repo_context, port);
    server.run();

    /*std::vector<std::future<void>> futures;

    auto fut = std::async([numOfIOContexts, threadsPerContext, port, repo_context, context] {
        Server server(numOfIOContexts, threadsPerContext, *context, *repo_context, port);
        server.run();
    });
    futures.push_back(std::move(fut));


    for (int i = 0; i < threadsForRepository; i++) {
        auto fut = std::async([repo_context] {
            repo_context->run();
        });
        futures.push_back(std::move(fut));
    }
    std::for_each(futures.begin(), futures.end(), [](std::future<void> &fut) {
        fut.wait();
    });*/

    return 0;
}
